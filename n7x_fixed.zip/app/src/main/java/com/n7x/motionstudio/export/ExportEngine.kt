package com.n7x.motionstudio.export

import android.content.Context
import android.graphics.Matrix
import android.graphics.Bitmap
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.SingleColorLut
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList
import com.n7x.motionstudio.data.AudioEntity
import com.n7x.motionstudio.data.MediaClipEntity
import com.n7x.motionstudio.data.OverlayEntity
import com.n7x.motionstudio.data.endMs
import com.n7x.motionstudio.data.lengthMs
import com.n7x.motionstudio.data.timelineMs
import com.n7x.motionstudio.effects.ColorOps
import com.n7x.motionstudio.effects.CubeLut
import com.n7x.motionstudio.animation.Keyframes
import com.n7x.motionstudio.animation.TextAnimations
import com.n7x.motionstudio.effects.Transitions
import kotlin.math.ceil
import kotlin.math.cos
import java.io.File

/**
 * Turns the project (clips, text, stickers, music) into a Media3 Composition.
 * Keyframe animation, transitions and text animations use the same maths as the preview.
 */
class ExportEngine(private val context: Context) {

    class Prepared(val composition: Composition, val tempFiles: List<File>)

    fun prepare(
        settings: ExportSettings,
        clips: List<MediaClipEntity>,
        overlays: List<OverlayEntity>,
        audios: List<AudioEntity>,
        workDir: File
    ): Prepared {
        val outW = settings.width
        val outH = settings.height
        val temp = mutableListOf<File>()
        val totalMs = clips.sumOf { it.timelineMs() }

        val sequences = mutableListOf<EditedMediaItemSequence>()
        sequences.add(EditedMediaItemSequence(clips.map { videoItem(it, settings, outW, outH) }))
        for (audio in audios) {
            audioSequence(audio, totalMs, workDir, temp)?.let { sequences.add(it) }
        }

        val overlayList = overlays.mapNotNull { overlayFor(it, outW, outH, totalMs) }
        val builder = Composition.Builder(sequences)
        // clip movement (keyframes + transitions) first, so text and stickers stay on top and do not
        // move with the clip
        val videoEffects = mutableListOf<Effect>()
        val plan = ClipPlan(clips)
        if (plan.active) {
            videoEffects.add(ClipMotion(plan, outW.toFloat() / outH))
            videoEffects.add(ClipColor(plan))
        }
        if (overlayList.isNotEmpty()) {
            videoEffects.add(OverlayEffect(ImmutableList.copyOf(overlayList)))
        }
        if (videoEffects.isNotEmpty()) {
            builder.setEffects(Effects(emptyList(), videoEffects))
        }
        return Prepared(builder.build(), temp)
    }

    private fun videoItem(clip: MediaClipEntity, s: ExportSettings, w: Int, h: Int): EditedMediaItem {
        val mediaItem = MediaItem.Builder()
            .setUri(Uri.fromFile(File(clip.path)))
            .apply {
                if (clip.isVideo) {
                    setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(clip.trimStartMs)
                            .setEndPositionMs(clip.trimEndMs)
                            .build()
                    )
                }
            }
            .build()

        val video = mutableListOf<Effect>()
        val audio = mutableListOf<AudioProcessor>()

        if (clip.isVideo && clip.speed != 1f) {
            video.add(SpeedChangeEffect(clip.speed))
            val sonic = SonicAudioProcessor()
            sonic.setSpeed(clip.speed)
            audio.add(sonic)
        }
        ColorOps.build(clip.filterId, clip.brightness, clip.contrast, clip.saturation)?.let {
            video.add(ColorMatrixEffect(it))
        }
        if (clip.isVideo && clip.lutPath.isNotEmpty()) {
            try {
                video.add(SingleColorLut.createFromCube(CubeLut.parse(File(clip.lutPath))))
            } catch (e: Exception) {
                // a broken LUT is skipped
            }
        }
        video.add(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT))
        if (s.fps > 0) video.add(FrameDropEffect.createDefaultFrameDropEffect(s.fps.toFloat()))
        if (clip.isVideo && clip.volume != 1f) audio.add(volumeProcessor(clip.volume))

        val item = EditedMediaItem.Builder(mediaItem).setEffects(Effects(audio, video))
        if (!clip.isVideo) {
            item.setDurationUs((clip.trimEndMs - clip.trimStartMs) * 1000L).setFrameRate(30)
        }
        return item.build()
    }

    private fun audioSequence(
        audio: AudioEntity,
        totalMs: Long,
        workDir: File,
        temp: MutableList<File>
    ): EditedMediaItemSequence? {
        val room = totalMs - audio.startMs
        if (room < 200L) return null
        val lengthMs = minOf(audio.lengthMs, room)
        val items = mutableListOf<EditedMediaItem>()
        if (audio.startMs > 0L) {
            val wav = File(workDir, "silence_${audio.id}.wav")
            SilenceWav.write(wav, audio.startMs)
            temp.add(wav)
            items.add(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).build())
        }
        val clip = MediaItem.Builder()
            .setUri(Uri.fromFile(File(audio.path)))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(audio.trimStartMs)
                    .setEndPositionMs(audio.trimStartMs + lengthMs)
                    .build()
            )
            .build()
        items.add(
            EditedMediaItem.Builder(clip)
                .setRemoveVideo(true)
                .setEffects(Effects(listOf<AudioProcessor>(volumeProcessor(audio.volume)), emptyList<Effect>()))
                .build()
        )
        return EditedMediaItemSequence(items)
    }

    private fun overlayFor(layer: OverlayEntity, w: Int, h: Int, totalMs: Long): TextureOverlay? {
        if (layer.text.isBlank()) return null
        val startUs = layer.startMs * 1000L
        val endUs = minOf(layer.endMs, totalMs) * 1000L
        if (startUs >= endUs) return null
        return AnimatedOverlay(layer, w, h, startUs, endUs)
    }

    private fun volumeProcessor(volume: Float): AudioProcessor {
        val processor = ChannelMixingAudioProcessor()
        processor.putChannelMixingMatrix(ChannelMixingMatrix(1, 1, floatArrayOf(volume)))
        processor.putChannelMixingMatrix(ChannelMixingMatrix(2, 2, floatArrayOf(volume, 0f, 0f, volume)))
        return processor
    }

    /** The same 4x5 colour matrix the preview uses, as a Media3 colour effect. */
    private class ColorMatrixEffect(m: FloatArray) : RgbMatrix {
        private val glMatrix = FloatArray(16).also { g ->
            for (row in 0..2) {
                for (col in 0..2) g[col * 4 + row] = m[row * 5 + col]
                g[3 * 4 + row] = m[row * 5 + 4] / 255f
            }
            g[3 * 4 + 3] = 1f
        }

        override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = glMatrix
    }

    /** Where every clip is on the timeline, with its keyframes and transitions. */
    private class ClipPlan(clips: List<MediaClipEntity>) {
        private val durations = clips.map { it.timelineMs() }
        private val types = clips.map { it.transitionType }
        private val lengths = clips.map { it.transitionMs }
        private val keys = clips.map { Keyframes.parse(it.keyframes) }
        private val starts = LongArray(clips.size).also { arr ->
            var t = 0L
            for (i in clips.indices) {
                arr[i] = t
                t += durations[i]
            }
        }
        val active = keys.any { it.isNotEmpty() } || clips.dropLast(1).any { it.transitionType != "none" }

        class Frame(
            val x: Float,
            val y: Float,
            val scale: Float,
            val rotation: Float,
            val opacity: Float,
            val flip: Float,
            val white: Float
        )

        /** The same mix the preview uses: the clip's own keyframes plus the transition. */
        fun at(tMs: Long): Frame {
            val adjust = Transitions.at(durations, types, lengths, tMs)
            var index = durations.lastIndex
            for (i in durations.indices) {
                if (tMs < starts[i] + durations[i]) {
                    index = i
                    break
                }
            }
            val base = Keyframes.evaluate(keys[index], (tMs - starts[index]).coerceAtLeast(0L))
            return Frame(
                x = base.x + adjust.dx,
                y = base.y + adjust.dy,
                scale = base.scale * adjust.scale,
                rotation = base.rotation + adjust.rotation,
                opacity = base.opacity * adjust.alpha,
                flip = adjust.flip,
                white = adjust.white
            )
        }
    }

    /** Position, zoom, rotation, slide and flip of the clips. Time is the position on the whole timeline. */
    private class ClipMotion(private val plan: ClipPlan, private val aspect: Float) : MatrixTransformation {
        override fun getMatrix(presentationTimeUs: Long): Matrix {
            val f = plan.at(presentationTimeUs / 1000L)
            val m = Matrix()
            // flip is a turn around the vertical axis, drawn as the picture getting narrower
            val flipScale = cos(Math.toRadians(f.flip.toDouble())).toFloat().coerceAtLeast(0.001f)
            val scale = f.scale.coerceAtLeast(0.001f)
            m.postScale(scale * flipScale, scale)
            if (f.rotation != 0f) {
                // turn in real pixels, not in the stretched -1..1 space
                m.postScale(aspect, 1f)
                m.postRotate(-f.rotation)
                m.postScale(1f / aspect, 1f)
            }
            // the screen is 2 units wide and tall in this space, and y goes up
            m.postTranslate(2f * f.x, -2f * f.y)
            return m
        }
    }

    /** Clip opacity (fade to black) and the white flash. */
    private class ClipColor(private val plan: ClipPlan) : RgbMatrix {
        override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
            val f = plan.at(presentationTimeUs / 1000L)
            val white = f.white.coerceIn(0f, 1f)
            val k = f.opacity.coerceIn(0f, 1f) * (1f - white)
            return floatArrayOf(
                k, 0f, 0f, 0f,
                0f, k, 0f, 0f,
                0f, 0f, k, 0f,
                white, white, white, 1f
            )
        }
    }

    /**
     * A text or sticker layer with its start, stop and overall animations. The picture is drawn
     * again only when the visible letters or the rainbow colour change.
     */
    private class AnimatedOverlay(
        private val layer: OverlayEntity,
        private val outW: Int,
        private val outH: Int,
        private val startUs: Long,
        private val endUs: Long
    ) : BitmapOverlay() {
        private var lastKey = Int.MIN_VALUE
        private var lastBitmap: Bitmap? = null

        private fun stateAt(presentationTimeUs: Long) =
            TextAnimations.evaluate(layer, presentationTimeUs / 1000L - layer.startMs)

        override fun getBitmap(presentationTimeUs: Long): Bitmap {
            val state = stateAt(presentationTimeUs)
            val count = ceil(layer.text.length * state.reveal).toInt().coerceIn(0, layer.text.length)
            val hueStep = state.hue?.let { ((it % 360f + 360f) % 360f / 4f).toInt() } ?: -1
            val key = count * 1000 + hueStep + 1
            var bitmap = lastBitmap
            if (bitmap == null || key != lastKey) {
                bitmap = OverlayRenderer.render(
                    layer, outW, outH, count, if (hueStep >= 0) hueStep * 4f else null
                ) ?: Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
                lastBitmap = bitmap
                lastKey = key
            }
            return bitmap!!
        }

        override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
            val state = stateAt(presentationTimeUs)
            val visible = presentationTimeUs in startUs until endUs
            val alpha = if (visible) (layer.opacity * state.alpha).coerceIn(0f, 1f) else 0f
            val scale = state.scale.coerceAtLeast(0.001f)
            return OverlaySettings.Builder()
                .setBackgroundFrameAnchor(2f * (layer.x + state.dx), -2f * (layer.y + state.dy))
                .setRotationDegrees(-(layer.rotation + state.rotation))
                .setScale(scale, scale)
                .setAlphaScale(alpha)
                .build()
        }
    }
}
